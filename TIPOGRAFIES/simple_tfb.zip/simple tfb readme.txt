- Simple Tfb.tts is free for personal use.

- Only to distribute dafont.com & truefonts.blogspot.com, other sites violate copyright.

- Plese visit my blog: http://truefonts.blogspot.com


